<?php

namespace App\Controllers;

class Contacto extends BaseController
{
    public function index(): string
    {
        return view('Contacto');
    }
}