<?php

namespace App\Controllers;

class gracias extends BaseController
{
    public function index(): string
    {
        return view('gracias');
    }
}
